﻿Module Gabi
    Public Gcompu As String
    Public Gmate As String
    Public Gingles As String
    Public Gcompu1 As String
    Public Gcompu2 As String
    Public Gcompu3 As String
    Public Gcompu4 As String
    Public Gmate1 As String
    Public Gmate2 As String
    Public Gmate3 As String
    Public Gmate4 As String
    Public Gingles1 As String
    Public Gingles2 As String
    Public Gingles3 As String
    Public Gingles4 As String
End Module
