﻿Module Andre
    Public Lcompu As String
    Public Lmate As String
    Public Lingles As String
    Public Lcompu1 As String
    Public Lcompu2 As String
    Public Lcompu3 As String
    Public Lcompu4 As String
    Public Lmate1 As String
    Public Lmate2 As String
    Public Lmate3 As String
    Public Lmate4 As String
    Public Lingles1 As String
    Public Lingles2 As String
    Public Lingles3 As String
    Public Lingles4 As String
End Module
