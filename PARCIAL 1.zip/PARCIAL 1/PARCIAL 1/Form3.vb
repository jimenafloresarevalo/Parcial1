﻿Public Class Form3
    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Application.Exit()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim a, b, c, d, i, f, g, h, j, k, l, m As Integer


        Fer.Bmate1 = TextBox4.Text
        Fer.Bmate2 = TextBox5.Text
        Fer.Bmate3 = TextBox6.Text
        Fer.Bmate4 = TextBox7.Text
        a = Fer.Bmate1
        b = Fer.Bmate2
        c = Fer.Bmate3
        d = Fer.Bmate4
        Fer.Bmate = (a + b + c + d) / 4
        TextBox1.Text = Fer.Bmate

        Andre.Lmate1 = TextBox8.Text
        Andre.Lmate2 = TextBox9.Text
        Andre.Lmate3 = TextBox10.Text
        Andre.Lmate4 = TextBox11.Text
        i = Andre.Lmate1
        f = Andre.Lmate2
        g = Andre.Lmate3
        h = Andre.Lmate4
        Andre.Lmate = (i + f + g + h) / 4
        TextBox2.Text = Andre.Lmate


        Gabi.Gmate1 = TextBox12.Text
        Gabi.Gmate2 = TextBox13.Text
        Gabi.Gmate3 = TextBox14.Text
        Gabi.Gmate4 = TextBox15.Text
        j = Gabi.Gmate1
        k = Gabi.Gmate2
        l = Gabi.Gmate3
        m = Gabi.Gmate4
        Gabi.Gmate = (j + k + l + m) / 4
        TextBox3.Text = Gabi.Gmate

    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Me.Close()
    End Sub

    Private Sub Form3_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class