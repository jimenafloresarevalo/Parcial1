﻿Public Class Form7
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Application.Exit()
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Dim promedio As Integer
        Dim a, b, c As Integer



        TextBox1.Text = Gabi.Gcompu1
        TextBox2.Text = Gabi.Gmate1
        TextBox3.Text = Gabi.Gingles1
        TextBox8.Text = Gabi.Gcompu2
        TextBox10.Text = Gabi.Gmate2
        TextBox9.Text = Gabi.Gingles2
        TextBox13.Text = Gabi.Gcompu3
        TextBox12.Text = Gabi.Gmate3
        TextBox11.Text = Gabi.Gingles3
        TextBox16.Text = Gabi.Gcompu4
        TextBox15.Text = Gabi.Gmate4
        TextBox14.Text = Gabi.Gingles4
        TextBox19.Text = Gabi.Gcompu
        TextBox18.Text = Gabi.Gmate
        TextBox17.Text = Gabi.Gingles


        a = Gabi.Gcompu
        b = Gabi.Gmate
        c = Gabi.Gingles
        promedio = (a + b + c) / 3


        TextBox4.Text = promedio


        If (Gabi.Gcompu >= 60) Then
            TextBox5.Text = "APROBADO"
        Else
            TextBox5.Text = "REPROBADO"
        End If
        If (Gabi.Gmate >= 60) Then
            TextBox6.Text = "APROBADO"
        Else
            TextBox6.Text = "REPROBADO"
        End If
        If (Gabi.Gingles >= 60) Then
            TextBox7.Text = "APROBADO"
        Else
            TextBox7.Text = "REPROBADO"
        End If
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Me.Close()
    End Sub

    Private Sub TextBox8_TextChanged(sender As Object, e As EventArgs) Handles TextBox8.TextChanged

    End Sub
End Class