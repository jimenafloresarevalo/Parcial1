﻿Public Class Form6
    Private Sub Label4_Click(sender As Object, e As EventArgs) Handles Label4.Click

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Application.Exit()
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Dim promedio As Integer
        Dim a, b, c As Integer



        TextBox1.Text = Andre.Lcompu1
        TextBox2.Text = Andre.Lmate1
        TextBox3.Text = Andre.Lingles1
        TextBox8.Text = Andre.Lcompu2
        TextBox10.Text = Andre.Lmate2
        TextBox9.Text = Andre.Lingles2
        TextBox13.Text = Andre.Lcompu3
        TextBox12.Text = Andre.Lmate3
        TextBox11.Text = Andre.Lingles3
        TextBox16.Text = Andre.Lcompu4
        TextBox15.Text = Andre.Lmate4
        TextBox14.Text = Andre.Lingles4
        TextBox19.Text = Andre.Lcompu
        TextBox18.Text = Andre.Lmate
        TextBox17.Text = Andre.Lingles


        a = Andre.Lcompu
        b = Andre.Lmate
        c = Andre.Lingles
        promedio = (a + b + c) / 3


        TextBox4.Text = promedio


        If (Andre.Lcompu >= 60) Then
            TextBox5.Text = "APROBADO"
        Else
            TextBox5.Text = "REPROBADO"
        End If
        If (Andre.Lmate >= 60) Then
            TextBox6.Text = "APROBADO"
        Else
            TextBox6.Text = "REPROBADO"
        End If
        If (Andre.Lingles >= 60) Then
            TextBox7.Text = "APROBADO"
        Else
            TextBox7.Text = "REPROBADO"
        End If
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Me.Close()
    End Sub

    Private Sub Form6_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class