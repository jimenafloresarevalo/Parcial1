﻿Public Class Form5


    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Application.Exit()
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Dim promedio As Integer
        Dim a, b, c As Integer



        TextBox1.Text = Fer.Bcompu1
        TextBox2.Text = Fer.Bmate1
        TextBox3.Text = Fer.Bingles1
        TextBox8.Text = Fer.Bcompu2
        TextBox10.Text = Fer.Bmate2
        TextBox9.Text = Fer.Bingles2
        TextBox13.Text = Fer.Bcompu3
        TextBox12.Text = Fer.Bmate3
        TextBox11.Text = Fer.Bingles3
        TextBox16.Text = Fer.Bcompu4
        TextBox15.Text = Fer.Bmate4
        TextBox14.Text = Fer.Bingles4
        TextBox19.Text = Fer.Bcompu
        TextBox18.Text = Fer.Bmate
        TextBox17.Text = Fer.Bingles


        a = Fer.Bcompu
        b = Fer.Bmate
        c = Fer.Bingles
        promedio = (a + b + c) / 3


        TextBox4.Text = promedio


        If (Fer.Bcompu >= 60) Then
            TextBox5.Text = "APROBADO"
        Else
            TextBox5.Text = "REPROBADO"
        End If
        If (Fer.Bmate >= 60) Then
            TextBox6.Text = "APROBADO"
        Else
            TextBox6.Text = "REPROBADO"
        End If
        If (Fer.Bingles >= 60) Then
            TextBox7.Text = "APROBADO"
        Else
            TextBox7.Text = "REPROBADO"
        End If





    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Me.Close()
    End Sub
End Class