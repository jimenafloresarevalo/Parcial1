﻿Public Class Form1



    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        If TextBox1.Text = "0001" And TextBox2.Text = "0001" Then

            MessageBox.Show("Bienvenido a ITSO_PLATFORM")
            Form2.Show()

        End If

        If TextBox1.Text = "0002" And TextBox2.Text = "0002" Then

            MessageBox.Show("Bienvenido a ITSO_PLATFORM")
            Form3.Show()

        End If
        If TextBox1.Text = "0003" And TextBox2.Text = "0003" Then

            MessageBox.Show("Bienvenido a ITSO_PLATFORM")
            Form4.Show()
        End If
        If TextBox1.Text = "2022B04" And TextBox2.Text = "B004" Then

            MessageBox.Show("Bienvenido a ITSO_PLATFORM")

            Form5.Show()

        End If
        If TextBox1.Text = "2022L05" And TextBox2.Text = "L005" Then

            MessageBox.Show("Bienvenido a ITSO_PLATFORM")

            Form6.Show()

        End If
        If TextBox1.Text = "2022G06" And TextBox2.Text = "G006" Then

            MessageBox.Show("Bienvenido a ITSO_PLATFORM")

            Form7.Show()

        End If
        TextBox1.Text = ""
        TextBox2.Text = ""




    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click

        Application.Exit()

    End Sub
End Class
