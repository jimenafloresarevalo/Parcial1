﻿Module Fer
    Public Bcompu As String
    Public Bmate As String
    Public Bingles As String
    Public Bcompu1 As String
    Public Bcompu2 As String
    Public Bcompu3 As String
    Public Bcompu4 As String
    Public Bmate1 As String
    Public Bmate2 As String
    Public Bmate3 As String
    Public Bmate4 As String
    Public Bingles1 As String
    Public Bingles2 As String
    Public Bingles3 As String
    Public Bingles4 As String





End Module
